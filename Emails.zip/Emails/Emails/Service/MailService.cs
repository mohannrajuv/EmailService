﻿using Emails.Models;
using MailKit.Net.Smtp;
//using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Security.Policy;

namespace Emails.Service
{
    public class MailService : IMailService
    {
        
        private readonly MailSettings _mailSettings;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailSettings"></param>
        public MailService(IOptions<MailSettings> mailSettings)
        {
            _mailSettings = mailSettings.Value;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailRequest"></param>
        /// <returns></returns>
        public async Task SendEmailAsync(MailRequest mailRequest)
        {
            try
            {
                var email = new MimeMessage();
                email.Sender = MailboxAddress.Parse(_mailSettings.FromMail);
                email.To.Add(MailboxAddress.Parse(mailRequest.ToEmail));
                email.Subject = mailRequest.Subject;
                var builder = new BodyBuilder();
                if (mailRequest.Attachments != null)
                {
                    byte[] fileBytes;
                    foreach (var file in mailRequest.Attachments)
                    {
                        if (file.Length > 0)
                        {
                            using (var ms = new MemoryStream())
                            {
                                file.CopyTo(ms);
                                fileBytes = ms.ToArray();
                            }
                            builder.Attachments.Add(file.FileName, fileBytes, ContentType.Parse(file.ContentType));
                        }
                    }
                }
                builder.HtmlBody = mailRequest.Body;
                email.Body = builder.ToMessageBody();

                using var smtp = new SmtpClient();
                smtp.Connect(_mailSettings.Host, _mailSettings.Port, SecureSocketOptions.StartTls);
                //smtp.Authenticate(_mailSettings.FromMail, _mailSettings.Password);
                await smtp.SendAsync(email);
                smtp.Disconnect(true);
            }
            catch (Exception ex)
            {

                throw ex.InnerException;
            }
           


            #region * Old Code

            //System.Net.Mail.MailMessage email = new System.Net.Mail.MailMessage(new System.Net.Mail.MailAddress(_mailSettings.FromMail, "Test Mail.."), new System.Net.Mail.MailAddress(mailRequest.ToEmail));
            //email.Subject = mailRequest.Subject;
            //var builder = new BodyBuilder();
            //if (mailRequest.Attachments != null)
            //{
            //    byte[] fileBytes;
            //    foreach (var file in mailRequest.Attachments)
            //    {
            //        if (file.Length > 0)
            //        {
            //            using (var ms = new MemoryStream())
            //            {
            //                file.CopyTo(ms);
            //                fileBytes = ms.ToArray();
            //            }
            //            builder.Attachments.Add(file.FileName, fileBytes, ContentType.Parse(file.ContentType));
            //        }
            //    }
            //}
            //builder.HtmlBody = mailRequest.Body;
            //email.Body = mailRequest.Body;
            //email.IsBodyHtml = true;
            //using var smtp = new System.Net.Mail.SmtpClient(_mailSettings.Host);
            ////smtp.Credentials = new System.Net.NetworkCredential(_mailSettings.Mail, _mailSettings.Password);
            //smtp.EnableSsl = true;
            //await smtp.SendMailAsync(email);

            ////

            //System.Net.Mail.MailMessage m = new System.Net.Mail.MailMessage(
            //            new System.Net.Mail.MailAddress(_mailSettings.Mail, "Web Registration"), new System.Net.Mail.MailAddress(mailRequest.ToEmail));
            //m.Subject = mailRequest.Subject;
            //m.Body = mailRequest.Body;//string.Format("Dear {0}<BR/>Thank you for your registration, please click on the below link to complete your registration: <a href=\"{1}\" title=\"User Email Confirm\">{1}</a>", "Mohanraju", Url.Action("ConfirmEmail", "Account", new { Token = "11", Email = "mohanraju.veerappan@ducenit.com" }, Request.u.Scheme));
            //m.IsBodyHtml = true;
            //System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient(_mailSettings.Host);
            //smtp.Credentials = new System.Net.NetworkCredential(_mailSettings.Mail, _mailSettings.Password);
            //smtp.EnableSsl = true;
            //smtp.Send(m);

            #endregion
        }
    }
}
